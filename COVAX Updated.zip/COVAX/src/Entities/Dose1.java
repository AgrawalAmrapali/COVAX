package Entities;

public class Dose1 {
}
