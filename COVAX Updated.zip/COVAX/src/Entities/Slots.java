package Entities;

public class Slots {
}
