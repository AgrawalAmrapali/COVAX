package Entities;

public class Daily_Status {
}
