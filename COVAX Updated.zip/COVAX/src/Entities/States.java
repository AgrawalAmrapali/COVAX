package Entities;

public class States {

}
