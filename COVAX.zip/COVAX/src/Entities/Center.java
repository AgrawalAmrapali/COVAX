package Entities;

public class Center {
}
