package Entities;

public class District {
}
