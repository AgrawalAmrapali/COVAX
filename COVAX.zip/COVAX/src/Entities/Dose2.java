package Entities;

public class Dose2 {
}
