package Entities;

public class Vaccine {
}
