package Entities;

public class User {
}
