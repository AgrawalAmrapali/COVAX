package Entities;

public class City {
}
